module HsParseUtils
{-# DEPRECATED "This module has moved to Language.Haskell.ParseUtils" #-}
(module Language.Haskell.ParseUtils) where
import Language.Haskell.ParseUtils
