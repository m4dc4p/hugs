module HsLexer
{-# DEPRECATED "This module has moved to Language.Haskell.Lexer" #-}
(module Language.Haskell.Lexer) where
import Language.Haskell.Lexer
