module HsPretty
{-# DEPRECATED "This module has moved to Language.Haskell.Pretty" #-}
(module Language.Haskell.Pretty) where
import Language.Haskell.Pretty
