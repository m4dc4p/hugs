module DiffArray
  {-# DEPRECATED "This module has moved to Data.Array.Diff" #-} 
  (module Data.Array.Diff) where
import Data.Array.Diff
