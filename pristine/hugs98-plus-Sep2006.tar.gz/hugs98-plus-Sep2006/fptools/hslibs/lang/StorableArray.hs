module StorableArray
  {-# DEPRECATED "This module has moved to Data.Array.Storable" #-} 
  (module Data.Array.Storable) where
import Data.Array.Storable
