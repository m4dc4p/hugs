module Generics
  {-# DEPRECATED "This library has moved to Data.Generics" #-} 
  (module Data.Generics) where
import Data.Generics
