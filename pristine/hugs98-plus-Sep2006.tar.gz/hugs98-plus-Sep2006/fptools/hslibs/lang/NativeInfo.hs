module NativeInfo
  {-# DEPRECATED "This module has moved to System.Info" #-} 
  (module System.Info) where
import System.Info
