module Weak
  {-# DEPRECATED "This module has moved to System.Mem.Weak" #-} 
  (module System.Mem.Weak) where
import System.Mem.Weak
