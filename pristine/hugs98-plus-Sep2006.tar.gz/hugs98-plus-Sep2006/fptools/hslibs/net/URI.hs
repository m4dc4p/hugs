module URI
{-# DEPRECATED "This module has moved to Network.URI" #-}
(module Network.URI) where
import Network.URI
