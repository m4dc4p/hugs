To build:

  csc /out:hswrapgen.exe *.cs

