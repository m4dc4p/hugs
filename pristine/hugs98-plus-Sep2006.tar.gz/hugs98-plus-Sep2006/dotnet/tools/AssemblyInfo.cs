using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("The sof company")]
[assembly: AssemblyCopyright("Copyright (c) 2002-2003, sof")]
[assembly: AssemblyTrademark("")]

[assembly: AssemblyProduct("HsWrapGen")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]

[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyTitle("HsWrapGen")]
[assembly: AssemblyDescription("Haskell .NET wrapper generator")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
