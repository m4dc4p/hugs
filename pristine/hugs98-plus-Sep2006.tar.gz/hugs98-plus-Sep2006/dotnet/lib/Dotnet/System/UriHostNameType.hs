module Dotnet.System.UriHostNameType where

import Dotnet
import qualified Dotnet.System.Enum

data UriHostNameType_ a
type UriHostNameType a = Dotnet.System.Enum.Enum (UriHostNameType_ a)


