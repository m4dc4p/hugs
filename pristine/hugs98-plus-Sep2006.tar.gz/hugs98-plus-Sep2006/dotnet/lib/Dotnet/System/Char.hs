module Dotnet.System.Char where

import Dotnet
import qualified Dotnet.System.Object

data Char_ a
type Char a = Dotnet.System.Object.Object (Char_ a)

