module Dotnet.System.IO.DirectoryInfo 
	( module Dotnet.System.IO.DirectoryInfo ) where

import qualified Dotnet.System.Object

data DirectoryInfo_ a
type DirectoryInfo a = Dotnet.System.Object.Object (DirectoryInfo_ a)

