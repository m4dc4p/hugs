module Dotnet.System.Xml.XmlSpace where

import Dotnet
import qualified Dotnet.System.Enum

data XmlSpace_ a
type XmlSpace a = Dotnet.System.Enum.Enum (XmlSpace_ a)


