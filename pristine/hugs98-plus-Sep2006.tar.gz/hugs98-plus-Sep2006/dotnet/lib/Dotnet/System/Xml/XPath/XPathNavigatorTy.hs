module Dotnet.System.Xml.XPath.XPathNavigatorTy where

import qualified Dotnet.System.Object

data XPathNavigator_ a
type XPathNavigator a = Dotnet.System.Object.Object (XPathNavigator_ a)

