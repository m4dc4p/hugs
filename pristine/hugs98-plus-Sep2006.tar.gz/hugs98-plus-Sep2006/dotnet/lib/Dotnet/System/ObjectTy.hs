module Dotnet.System.ObjectTy (Dotnet.Object(..)) where

import qualified Dotnet

--data Object_ a
--type Object a = Dotnet.Object (Object_ a)




