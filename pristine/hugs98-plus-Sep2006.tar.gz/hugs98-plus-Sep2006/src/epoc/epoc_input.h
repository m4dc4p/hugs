/*
 * Prototypes for simplistic implementation of readline
 * by Glenn Strong <Glenn.Strong@cs.tcd.ie>
 *
*/
extern void add_history(char *);
extern char *readline(char *);

