//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Uninstaller.rc
//
#define dlgInstall                      101
#define bmpInstaller                    107
#define txtEdit                         1000
#define cmdBrowse                       1001
#define chkExecute                      1003
#define bmpLogo                         1003
#define chkShortcut                     1004
#define chkShortcutDesktop              1004
#define chkShortcutStart                1005
#define chkRegisterFiles                1005
#define barTop                          1009
#define prgBar                          1012
#define lblWelcome                      1013
#define lblInstallTo                    1014
#define lblInstallFile                  1015
#define lblSpace                        1016
#define lblMessage                      1016
#define lstItems                        1019
#define chkDeleteModified               1020
#define dlgUninstall                    -7872

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
