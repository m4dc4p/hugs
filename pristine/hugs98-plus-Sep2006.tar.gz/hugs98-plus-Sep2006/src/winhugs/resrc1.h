//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by winhugs.rc
//
#define DLG_OPTCOMPILE                  9
#define BMP_ABOUT                       106
#define DLG_OPTRUNTIME                  108
#define ID_MRU                          150
#define IDS_STRING153                   153
#define BMP_TOOLBAR                     1004
#define SPN_HEAPSIZE                    1004
#define IDC_RICHEDIT21                  1005
#define rtfPreview                      1005
#define txtPath                         1005
#define rtfAbout                        1005
#define ID_RTF                          1006
#define IDC_CHECK1                      1012
#define chkOverlap                      1012
#define IDC_CHECK2                      1013
#define chkOverlapUnsafe                1013
#define IDC_CHECK3                      1014
#define chkHereDocs                     1014
#define lstFontFace                     1016
#define chkUserShow                     1016
#define lstEditor                       1017
#define chkFontBold                     1018
#define chkFontItalic                   1019
#define txtFontSize                     1021
#define spnFontSize                     1022
#define txtEditor                       1024
#define spnHeapSize                     1027
#define txtHeapSize                     1028
#define chkPrintStats                   1029
#define chkPrintGC                      1030
#define chkPrintType                    1031
#define chkListLoading                  1034
#define chkAutoReload                   1035
#define optCompatible                   1036
#define IDC_RADIO2                      1037
#define optExtensions                   1037
#define DLG_MAIN                        28445
#define DLG_OPTHUGS                     28446
#define ID_USERSGUIDE                   40007
#define ID_WWWHUGS                      40008
#define ID_WWWHASKELL                   40009
#define ID_HELPCONTENTS                 40010
#define ID_Menu                         40016
#define ID_DELETE                       40020
#define ID_CLEARSCREEN                  40021
#define ID_SELECTALL                    40022
#define ID_LIBRARIES                    40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
