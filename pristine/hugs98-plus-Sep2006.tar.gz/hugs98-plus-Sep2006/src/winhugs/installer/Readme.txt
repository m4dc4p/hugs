Windows installer, slightly modified from the one for Pingus
<http://pingus.seul.org/>.  Original and modifications by Neil Mitchell.

Please avoid reformatting the source, as Neil wishes to coordinate
the two versions.  Hopefully the common bits will be split off into a
separate package some time.
