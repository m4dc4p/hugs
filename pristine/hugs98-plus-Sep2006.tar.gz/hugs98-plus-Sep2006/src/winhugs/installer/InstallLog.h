
void StartInstallLog(char* File);
void StopInstallLog(bool Delete);
void WriteInstallLog(char* Format, ...);

