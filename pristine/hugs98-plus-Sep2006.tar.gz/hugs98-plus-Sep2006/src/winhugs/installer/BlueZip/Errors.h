//Error messages, with descriptive text
//Can be turned off with the command
//Can either send the text, or 0xffffffff

