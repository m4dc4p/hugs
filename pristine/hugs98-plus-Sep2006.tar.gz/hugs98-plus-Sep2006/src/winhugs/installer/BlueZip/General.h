
LPTSTR CopyString(LPCTSTR s);
